# New module for pre-screening video segments
